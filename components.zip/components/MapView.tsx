'use client';
import { useEffect, useRef, useState } from 'react';
import DetailPanel from '@/components/DetailPanel';
import { useMapStore } from '@/store/useMapStore';

declare global {
  interface Window { kakao: any; }
}

/** ⚠️ 카카오 JS Key를 여기에 설정합니다. Vercel에서 사용하려면 카카오 개발자센터에 Vercel 도메인을 등록해야 합니다. */
const KAKAO_JS_KEY = '21b4298df1918600fd43c18a65d03b57';

/** ---- Kakao SDK Loader (Race-free, 로드 완료 보장) ---- */
const kakaoReadyPromiseRef: { current: Promise<void> | null } = { current: null };

function ensureKakaoLoaded(appKey: string) {
  // 클라이언트 환경이 아니면 즉시 종료
  if (typeof window === 'undefined') {
    return Promise.reject(new Error('window object is undefined. This component must run in the browser.'));
  }
  
  // 이미 로드 중이거나 완료되었다면 기존 Promise 반환
  if (kakaoReadyPromiseRef.current) return kakaoReadyPromiseRef.current;

  // 로드/준비 Promise 생성
  kakaoReadyPromiseRef.current = new Promise<void>((resolve, reject) => {
    // 1. 이미 kakao 객체가 있고, maps가 준비되었는지 확인
    const isKakaoReady = () => !!(window.kakao?.maps && window.kakao.maps.MarkerClusterer && window.kakao.maps.services);

    if (isKakaoReady()) {
      resolve();
      return;
    }

    // 2. SDK 스크립트 로드
    const scriptId = 'kakao-sdk';
    let script = document.getElementById(scriptId) as HTMLScriptElement | null;
    
    // SDK 스크립트가 없으면 생성하여 삽입
    if (!script) {
      script = document.createElement('script');
      script.id = scriptId;
      // 라이브러리(clusterer, services)를 함께 요청합니다.
      const src = `https://dapi.kakao.com/v2/maps/sdk.js?appkey=${appKey}&autoload=false&libraries=clusterer,services`;
      script.src = src;
      document.head.appendChild(script);
    } 

    // 3. 스크립트 로드 완료 후 `load` 호출 및 초기화 대기
    const loadHandler = () => {
      // SDK가 로드되면 `kakao.maps.load`를 호출하여 필요한 모듈을 로드하고 준비가 완료될 때 resolve
      window.kakao.maps.load(() => {
        // load 완료 후에도 혹시 모를 비동기 준비를 위해 재확인
        const checkReady = () => {
          if (isKakaoReady()) {
            resolve();
          } else {
            // 아직 준비 안 됐으면 다음 프레임에 다시 확인
            requestAnimationFrame(checkReady); 
          }
        };
        checkReady();
      });
    };

    script.onload = loadHandler;
    script.onerror = () => reject(new Error('Kakao SDK load failed'));
    
    // 이미 스크립트는 있지만 아직 로드 이벤트가 발생하지 않았을 경우 처리
    if (script.hasAttribute('data-loaded')) {
      loadHandler();
    }
    
    // 스크립트 로드가 완료되었는지 확인 (혹시 브라우저 캐시 등으로 이미 로드된 경우)
    if (window.kakao?.maps) {
        loadHandler();
    }
  });

  return kakaoReadyPromiseRef.current;
}


/** 상단 필터 버튼들 */
const FILTER_BUTTONS = [
  { key: 'male_toilet', label: '남자화장실' },
  { key: 'female_toilet', label: '여자화장실' },
  { key: 'baby_change', label: '기저귀교체' },
  { key: 'male_disabled', label: '장애인화장실' },
];

/** 🔵 내 위치 오버레이용 스타일 주입 (한 번만) */
function injectMyLocStylesOnce() {
  if (document.getElementById('my-loc-style')) return;
  const style = document.createElement('style');
  style.id = 'my-loc-style';
  style.textContent = `
    .ml-container{position:absolute;transform:translate(-50%,-50%);}
    .ml-dot{
      width:20px;height:20px;border-radius:50%;
      background:#1a73e8;
      box-shadow:0 0 0 4px #fff inset, 0 1px 2px rgba(0,0,0,.15);
    }
    .ml-rot{position:absolute;left:50%;top:0;transform:translate(-50%,-60%) rotate(0deg);transform-origin:50% 12px;}
    .ml-tri{
      width:0;height:0;
      border-left:6px solid transparent;
      border-right:6px solid transparent;
      border-bottom:9px solid #1a73e8;
      filter: drop-shadow(0 1px 1px rgba(0,0,0,.25));
    }
    .ml-accuracy{
      position:absolute;
      pointer-events:none;
    }`;
  document.head.appendChild(style);
}

/** 🔵 내 위치 오버레이 생성 */
function createMyLocationOverlay(kakao: any, map: any, lat: number, lng: number) {
  injectMyLocStylesOnce();
  const container = document.createElement('div');
  container.className = 'ml-container';
  const dot = document.createElement('div');
  dot.className = 'ml-dot';
  const rot = document.createElement('div');
  rot.className = 'ml-rot';
  const tri = document.createElement('div');
  tri.className = 'ml-tri';
  rot.appendChild(tri);
  container.appendChild(dot);
  container.appendChild(rot);
  
  const overlay = new kakao.maps.CustomOverlay({
    position: new kakao.maps.LatLng(lat, lng),
    content: container,
    yAnchor: 0.5, xAnchor: 0.5
  });
  
  overlay.setMap(map);

  const circle = new kakao.maps.Circle({
    center: new kakao.maps.LatLng(lat, lng),
    radius: 40,
    strokeWeight: 2,
    strokeColor: '#1a73e8',
    strokeOpacity: 0.7,
    fillColor: '#1a73e8',
    fillOpacity: 0.25,
  });
  circle.setMap(map);

  return { overlay, circle, rotEl: rot };
}

/** ----- 좌표 검증 + 주소 지오코딩 fallback 유틸 ----- */
const KR = { minLat: 33, maxLat: 39, minLng: 124, maxLng: 132 };
const inRange = (v: number, min: number, max: number) =>
  Number.isFinite(v) && v >= min && v <= max;

export default function MapView() {
  const mapRef = useRef<HTMLDivElement>(null);
  const clustererRef = useRef<any>(null);
  const mapObjRef = useRef<any>(null);

  // 내 위치 관련 ref
  const myLocRef = useRef<{ overlay: any; circle: any; rotEl: HTMLDivElement | null } | null>(null);
  const headingDegRef = useRef<number>(0);
  const cleanupOrientationRef = useRef<null | (() => void)>(null);
  const geoWatchIdRef = useRef<number | null>(null);
  const mapIdleListenerRef = useRef<any>(null);

  // 지오코딩 캐시 (주소→좌표)
  const geocodeCacheRef = useRef<Map<string, { lat: number; lng: number }>>(new Map());

  const [ready, setReady] = useState(false);
  const [query, setQuery] = useState('');
  const [activeFilters, setActiveFilters] = useState<string[]>([]);
  
  const { setSelected, filters } = useMapStore((s) => ({
    setSelected: s.setSelected,
    filters: s.filters ?? {},
  }));

  /** 1) SDK 로드 */
  useEffect(() => {
    const key = KAKAO_JS_KEY;
    if (!key) {
      console.error('KAKAO JS KEY missing');
      return;
    }

    let cancelled = false;

    ensureKakaoLoaded(key)
      .then(() => {
        if (!cancelled) setReady(true);
      })
      .catch((e) => console.error('Kakao SDK 로드 실패:', e));

    return () => {
      cancelled = true;
    };
  }, []);

  /** baby_change 포함 필터 매칭 (boolean/문자 모두 처리) */
  const matchesActiveFilters = (t: any) => {
    if (activeFilters.length === 0) return true;
    return activeFilters.every((key) => {
      const v = t[key];
      if (key === 'baby_change') {
        if (typeof v === 'boolean') return v === true;
        if (typeof v === 'string') {
          const s = v.trim().toUpperCase();
          return ['O', 'Y', 'YES', 'TRUE', '있음'].includes(s);
        }
        return false;
      }
      return v === 'O';
    });
  };

  const loadLastMyLocation = (): { lat: number; lng: number } | null => {
    if (typeof window === 'undefined') return null;
    try {
      const saved = window.sessionStorage.getItem('lastMyLocation');
      if (!saved) return null;
      const parsed = JSON.parse(saved);
      if (
        inRange(parsed.lat, KR.minLat, KR.maxLat) &&
        inRange(parsed.lng, KR.minLng, KR.maxLng)
      ) {
        return { lat: parsed.lat, lng: parsed.lng };
      }
    } catch (e) {
      console.warn('failed to read lastMyLocation', e);
    }
    return null;
  };

  /** 주소→좌표 fallback (좌표가 범위를 벗어날 때만) */
  const getValidLatLng = async (t: any): Promise<{ lat: number; lng: number } | null> => {
    const lat = Number(t.lat);
    const lng = Number(t.lng);
    // 1) 좌표가 정상인 경우 그대로 사용
    if (inRange(lat, KR.minLat, KR.maxLat) && inRange(lng, KR.minLng, KR.maxLng)) {
      return { lat, lng };
    }
    // 2) 좌표가 이상하면 주소 지오코딩
    const addr = (t.address || '').trim();
    if (!addr) return null;
    // 캐시 우선
    const cached = geocodeCacheRef.current.get(addr);
    if (cached) return cached;
    
    // 서버측 지오코딩 API 호출
    try {
      const r = await fetch(`/api/geocode?q=${encodeURIComponent(addr)}`, { cache: 'no-store' });
      if (!r.ok) throw new Error('Geocode API call failed');
      const j = await r.json();
      if (!Number.isFinite(j?.lat) || !Number.isFinite(j?.lng)) return null;
      const pos = { lat: Number(j.lat), lng: Number(j.lng) };
      geocodeCacheRef.current.set(addr, pos);
      return pos;
    } catch (e) {
      console.error('Geocoding fallback error:', e);
      return null;
    }
  };

  /** 2) 지도/클러스터러/데이터 */
  useEffect(() => {
    // ready가 true가 되었다는 것은 ensureKakaoLoaded가 성공했다는 의미
    if (!ready || !mapRef.current) return;
    
    // ⚠️ 이전 코드에서 초기화 스킵을 일으킬 수 있던 조건문 제거
    // if (!window.kakao?.maps || !window.kakao.maps.MarkerClusterer || !window.kakao.maps.services) { ... }
    
    const { kakao } = window;

    // 맵/클러스터러 최초 1회 초기화
    if (!mapObjRef.current) {
      // 🔹 1순위: 세션에 저장된 내 위치 (이전 방문에서 저장)
      const last = loadLastMyLocation();
      // 🔹 fallback: 세션에 없고, 권한도 아직 없을 때 사용할 기본값 (서울 시청)
      const initialLat = last?.lat ?? 37.5665;
      const initialLng = last?.lng ?? 126.9780;

      const map = new kakao.maps.Map(mapRef.current, {
        center: new kakao.maps.LatLng(initialLat, initialLng),
        level: 4,
      });
      mapObjRef.current = map;

      const clusterer = new kakao.maps.MarkerClusterer({
        map,
        averageCenter: true,
        minLevel: 7,
      });
      clustererRef.current = clusterer;

      // 🔹 저장된 위치가 있으면 내 위치 오버레이도 바로 복원
      if (last) {
        myLocRef.current = createMyLocationOverlay(kakao, map, last.lat, last.lng);
      }

      // 지도를 처음 탭하면 방향 권한 요청(iOS 등)
      mapRef.current.addEventListener('click', enableDeviceOrientation, { once: true });
    }

    const map = mapObjRef.current as any;
    const clusterer = clustererRef.current as any;

    // ----- 데이터 fetch + 깜빡임 방지 교체 -----
    let abortController: AbortController | null = null;
    let isFetching = false;

    const fetchAndDraw = async () => {
      if (isFetching) abortController?.abort();
      isFetching = true;
      abortController = new AbortController();

      try {
        const b = map.getBounds();
        const sw = b.getSouthWest();
        const ne = b.getNorthEast();
        
        const params = new URLSearchParams({
          sw: `${sw.getLat()},${sw.getLng()}`,
          ne: `${ne.getLat()},${ne.getLng()}`,
          public: '1',
        });
        if (filters?.baby_change) params.set('baby_change', '1');
        if (filters?.free) params.set('free', '1');
        if (filters?.gender_neutral) params.set('gender_neutral', '1');

        const res = await fetch(`/api/toilets?${params.toString()}`, { signal: abortController.signal });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        const toilets = Array.isArray(data) ? data : [];
        const filtered = toilets.filter((t: any) => matchesActiveFilters(t));

        // ---- 좌표 보정 후 마커 생성 (좌표 이상건만 주소 지오코딩) ----
        const markerPromises = filtered.map(async (t: any) => {
          const pos = await getValidLatLng(t);
          if (!pos) return null;

          const m = new kakao.maps.Marker({
            position: new kakao.maps.LatLng(pos.lat, pos.lng),
            clickable: true,
          });
          
          kakao.maps.event.addListener(m, 'click', () => {
            setSelected({
              id: t.id,
              name: t.name,
              address: t.address,
              lat: pos.lat,   // 보정 좌표 사용
              lng: pos.lng,
              category: t.category ?? null,
              phone: t.phone ?? null,
              open_time: t.open_time ?? null,
              male_toilet: t.male_toilet ?? null,
              female_toilet: t.female_toilet ?? null,
              male_disabled: t.male_disabled ?? null,
              female_disabled: t.female_disabled ?? null,
              male_child: t.male_child ?? null,
              female_child: t.female_child ?? null,
              emergency_bell: t.emergency_bell ?? null,
              cctv: t.cctv ?? null,
              baby_change: t.baby_change ?? null,
            });
          });
          return m;
        });

        const created = await Promise.all(markerPromises);
        const newMarkers = created.filter(Boolean) as any[];

        clusterer.clear();
        if (newMarkers.length > 0) clusterer.addMarkers(newMarkers);

      } catch (e: any) {
        if (e?.name !== 'AbortError') console.error('fetchAndDraw error:', e);
      } finally {
        isFetching = false;
      }
    };

    // 지도 idle 때마다
    if (!mapIdleListenerRef.current) {
      mapIdleListenerRef.current = kakao.maps.event.addListener(map, 'idle', () => {
        requestAnimationFrame(fetchAndDraw);
      });
      // 초기 로드
      fetchAndDraw();
    } else {
      // 필터 변경 즉시 반영
      fetchAndDraw();
    }

    // ✅ 내 위치: 오버레이 + 정확도 원 (마커 제거)
    const updateMyLocVisual = (lat: number, lng: number, accuracy?: number, headingDeg?: number | null) => {
      const loc = new kakao.maps.LatLng(lat, lng);

      if (!myLocRef.current) {
        myLocRef.current = createMyLocationOverlay(kakao, map, lat, lng);
      } else {
        myLocRef.current.overlay.setPosition(loc);
      }

      if (typeof accuracy === 'number' && Number.isFinite(accuracy)) {
        myLocRef.current!.circle.setRadius(Math.max(30, accuracy));
        myLocRef.current!.circle.setPosition(loc);
      } else {
        myLocRef.current!.circle.setPosition(loc);
      }

      const deg = (headingDeg ?? headingDegRef.current ?? 0) % 360;
      if (myLocRef.current?.rotEl) {
        myLocRef.current.rotEl.style.transform = `translate(-50%,-60%) rotate(${deg}deg)`;
      }

      // 🔹 마지막 내 위치 세션에 저장 (페이지 이동 후 복원용)
      if (typeof window !== 'undefined') {
        try {
          window.sessionStorage.setItem('lastMyLocation', JSON.stringify({ lat, lng }));
        } catch (e) {
          console.warn('failed to save lastMyLocation', e);
        }
      }
    };

    // 첫 위치 및 지속적인 위치 추적
    if (!geoWatchIdRef.current && navigator.geolocation) {
      // 1. 첫 위치 가져오기 (지도가 처음 내 위치로 이동)
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const { latitude, longitude, accuracy, heading } = pos.coords;
          updateMyLocVisual(latitude, longitude, accuracy, heading ?? null);
          
          // 🔹 첫 위치는 무조건 내 위치로 한번 이동
          const loc = new kakao.maps.LatLng(latitude, longitude);
          map.setLevel(4); // zoom 얼마나 할지
          map.panTo(loc);
        },
        (err) => console.warn('Geolocation error:', err),
        { enableHighAccuracy: true }
      );

      // 2. 위치 변화 감시 시작
      geoWatchIdRef.current = navigator.geolocation.watchPosition(
        (pos) => {
          const { latitude, longitude, accuracy, heading } = pos.coords;
          if (typeof heading === 'number' && Number.isFinite(heading)) {
            headingDegRef.current = heading;
          }
          updateMyLocVisual(latitude, longitude, accuracy, heading ?? null);
        },
        (err) => console.warn('Geolocation watch error:', err),
        { enableHighAccuracy: true }
      );
    }

    // 나침반(디바이스 방향) 활성화 함수
    function enableDeviceOrientation() {
      if (cleanupOrientationRef.current) return;

      const handler = (e: any) => {
        let alpha = (typeof e.alpha === 'number') ? e.alpha : null;
        if (alpha == null) return;
        const deg = (360 - alpha + 360) % 360;
        headingDegRef.current = deg;
        if (myLocRef.current?.rotEl) {
          myLocRef.current.rotEl.style.transform = `translate(-50%,-60%) rotate(${deg}deg)`;
        }
      };

      const DO = (window as any).DeviceOrientationEvent;
      if (DO && typeof DO.requestPermission === 'function') {
        DO.requestPermission().then((state: string) => {
          if (state === 'granted') {
            window.addEventListener('deviceorientation', handler, true);
            cleanupOrientationRef.current = () => window.removeEventListener('deviceorientation', handler, true);
          }
        }).catch(() => { });
      } else {
        window.addEventListener('deviceorientation', handler, true);
        cleanupOrientationRef.current = () => window.removeEventListener('deviceorientation', handler, true);
      }
    }

    // cleanup: 컴포넌트 언마운트 또는 이펙트 재실행 시 기존 작업 정리
    return () => {
      abortController?.abort();
      // watchPosition 정리
      if (geoWatchIdRef.current !== null && navigator.geolocation) {
        navigator.geolocation.clearWatch(geoWatchIdRef.current);
        geoWatchIdRef.current = null;
      }
      // deviceorientation 정리
      cleanupOrientationRef.current?.();
      cleanupOrientationRef.current = null;
      // 지도 이벤트 리스너 제거 (map.getBounds() 등을 사용하는 로직에 영향)
      if (mapIdleListenerRef.current) {
        kakao.maps.event.removeListener(map, 'idle', mapIdleListenerRef.current);
        mapIdleListenerRef.current = null;
      }
    };
  }, [ready, filters?.baby_change, filters?.free, filters?.gender_neutral, activeFilters, setSelected]);


  /** 3) 외부에서 지도 이동 이벤트 수신 */
  useEffect(() => {
    const handler = (e: Event) => {
      const ce = e as CustomEvent<{ lat: number; lng: number }>;
      if (!mapObjRef.current || !window.kakao) return;
      const { lat, lng } = ce.detail;
      const loc = new window.kakao.maps.LatLng(lat, lng);
      
      mapObjRef.current.panTo(loc);
      mapObjRef.current.setLevel(6);
    };

    window.addEventListener('map-move', handler as EventListener);

    return () => window.removeEventListener('map-move', handler as EventListener);
  }, []);

  /** 4) 🔍 주소+장소 통합 검색 */
  const handleSearch = (q: string) => {
    if (!q.trim()) return;
    if (!mapObjRef.current || !window.kakao?.maps?.services) {
      alert('지도 서비스가 로드되지 않았습니다.');
      return;
    }

    const { kakao } = window;
    const geocoder = new kakao.maps.services.Geocoder();
    const places = new kakao.maps.services.Places();

    // 공통: 중심 이동 함수
    const moveCenter = (lat: number, lng: number) => {
      const loc = new kakao.maps.LatLng(lat, lng);
      mapObjRef.current.setLevel(5);
      mapObjRef.current.panTo(loc);
    };

    const placeFallback = () => {
      places.keywordSearch(
        q,
        (res: any[], status: string) => {
          if (status === kakao.maps.services.Status.OK && res.length > 0) {
            const p = res[0];
            const lat = Number(p.y);
            const lng = Number(p.x);
            moveCenter(lat, lng);   // ✅ 마커 없이 중심 이동만
          } else {
            alert('해당 위치를 찾을 수 없습니다.');
          }
        },
        { useMapBounds: false, radius: 20000 }
      );
    };

    // 1차: 주소 검색 (지오코딩)
    geocoder.addressSearch(q, (res: any[], status: string) => {
      if (status === kakao.maps.services.Status.OK && res.length > 0) {
        const r = res[0];
        const lat = Number(r.y);
        const lng = Number(r.x);
        moveCenter(lat, lng);     // ✅ 마커 없이 중심 이동만
      } else {
        // 2차: 키워드(장소) 검색
        placeFallback();
      }
    });
  };

  /** 필터 토글 */
  const toggleFilter = (key: string) => {
    setActiveFilters((prev) =>
      prev.includes(key) ? prev.filter((f) => f !== key) : [...prev, key]
    );
  };

  return (
    <div className="relative w-full h-full">
      {/* 🔍 상단 검색 박스 */}
      <div className="absolute z-10 top-4 left-1/2 -translate-x-1/2 w-[min(680px,92vw)]">
        <div className="flex items-center gap-2 rounded-2xl bg-white/90 backdrop-blur px-3 py-2 shadow">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') handleSearch(query); }}
            placeholder="예: 주소를 입력하세요"
            className="w-full outline-none bg-transparent text-sm md:text-base"
          />
          <button
            onClick={() => handleSearch(query)}
            className="shrink-0 px-3 py-1.5 rounded-xl bg-black text-white text-sm"
          >
            검색
          </button>
        </div>

        {/* 필터 버튼 영역 */}
        <div className="flex justify-center mt-3 gap-2 overflow-x-auto">
          {FILTER_BUTTONS.map((f) => (
            <button
              key={f.key}
              onClick={() => toggleFilter(f.key)}
              className={`px-4 py-1.5 rounded-full text-sm whitespace-nowrap transition ${activeFilters.includes(f.key)
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-gray-800 border border-gray-200'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      <div ref={mapRef} className="w-full h-full" />
      <DetailPanel />
    </div>
  );
}