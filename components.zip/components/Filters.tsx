'use client';

import { useState } from 'react';
import { useMapStore } from '@/store/useMapStore';

declare global {
  interface Window {
    kakao: any;
  }
}

export default function Filters({ onSearch }: { onSearch?: (loc: any) => void }) {
  const { filters, setFilters, searchQuery, setSearchQuery } = useMapStore((s) => ({
    filters: s.filters ?? {},
    setFilters: s.setFilters,
    searchQuery: s.searchQuery ?? '',
    setSearchQuery: s.setSearchQuery,
  }));

  const [loading, setLoading] = useState(false);

  // ✅ 엔터 입력 시 검색 실행
  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && searchQuery.trim() !== '') {
      handleSearch();
    }
  };

  // ✅ 카카오 주소 검색 + 지도 이동 콜백
  const handleSearch = () => {
    if (!window.kakao?.maps?.services) {
      alert('Kakao 지도 서비스 로드 중입니다.');
      return;
    }
    const { kakao } = window;
    const geocoder = new kakao.maps.services.Geocoder();

    setLoading(true);
    geocoder.addressSearch(searchQuery, (results: any, status: any) => {
      setLoading(false);
      if (status === kakao.maps.services.Status.OK && results[0]) {
        const { x, y } = results[0];
        const loc = { lat: parseFloat(y), lng: parseFloat(x) };
        onSearch?.(loc);
      } else {
        alert('해당 지역을 찾을 수 없습니다.');
      }
    });
  };

  return (
    <div style={{ display: 'grid', gap: 12, fontSize: 14 }}>
      <h3 style={{ fontWeight: 600 }}>Search & Filters</h3>

      {/* 🔍 주소 검색 */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <input
          type="text"
          placeholder="주소를 입력해주세요"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          onKeyDown={handleKeyPress}
          style={{
            flex: 1,
            padding: '8px 10px',
            border: '1px solid #e5e7eb',
            borderRadius: 8,
          }}
        />
        <button
          type="button"
          onClick={handleSearch}
          disabled={loading}
          style={{
            padding: '7px 12px',
            borderRadius: 8,
            border: '1px solid #e5e7eb',
            background: loading ? '#f3f4f6' : '#fff',
            cursor: loading ? 'default' : 'pointer',
          }}
        >
          🔍
        </button>
      </div>

      {/* ☑ 필터 체크 */}
      <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <input
          type="checkbox"
          checked={!!filters.accessible}
          onChange={(e) => setFilters({ accessible: e.target.checked })}
        />
        Accessible
      </label>

      <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <input
          type="checkbox"
          checked={!!filters.baby_change}
          onChange={(e) => setFilters({ baby_change: e.target.checked })}
        />
        Baby change
      </label>

      <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <input
          type="checkbox"
          checked={!!filters.free}
          onChange={(e) => setFilters({ free: e.target.checked })}
        />
        Free
      </label>

      <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <input
          type="checkbox"
          checked={!!filters.gender_neutral}
          onChange={(e) => setFilters({ gender_neutral: e.target.checked })}
        />
        Gender-neutral
      </label>

      <button
        type="button"
        onClick={() =>
          setFilters({
            accessible: undefined,
            baby_change: undefined,
            free: undefined,
            gender_neutral: undefined,
          })
        }
        style={{
          marginTop: 4,
          padding: '6px 10px',
          border: '1px solid #e5e7eb',
          borderRadius: 8,
          background: '#f9fafb',
          fontSize: 13,
        }}
      >
        Reset filters
      </button>
    </div>
  );
}
